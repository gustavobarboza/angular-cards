export class CardInfo {
    imageUrl: string
    title: string
    description: string
    
}